# COVID19 elemzések

A `kontaktmatrix` modulhoz szükséges egy **MASZK** elemzés letöltése, amely a következőket tartalmazza:
- kontakt mátrixok
- kitöltők koreloszlása

A `modulok` mappa a következőkre tartalmaz `.wl` package fájlokat:
- modell generátorok
- kontakt mátrixok definiálása, generálása
- paraméterek


Az `elemzesek` mappa a következőket tartalmazza:
- *játszótér*: riportra közvetlenül nem szállított elemzések
- különböző riportok, demók plotjainak generálását elvégző szkriptek
